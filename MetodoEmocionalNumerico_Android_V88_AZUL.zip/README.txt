Método Emocional Numérico - Android V88

Esta versión corrige definitivamente la apertura de enlaces externos:
TikTok, Instagram y YouTube se envían a Android mediante ACTION_VIEW,
por lo que el sistema puede abrir la app correspondiente o el navegador.

La aplicación web incluida es la V83.
Versión Android: 1.2, versionCode 3.

Compilación:
gradle assembleDebug


V86: tema interior actualizado a tonalidades azuladas suaves, manteniendo el texto en negro.

V87: eliminado el botón "ANALIZAR TODO" de la pestaña Sorteos de Navidad porque la misma función ya está disponible desde la pantalla principal.
V88: la opción "Analizar todo" de la pantalla principal abre ahora una pantalla exclusiva que muestra únicamente el análisis completo, sin los controles de Sorteos de Navidad ni la búsqueda de palabras.
