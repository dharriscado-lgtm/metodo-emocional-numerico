MÉTODO EMOCIONAL NUMÉRICO — ANDROID

Este proyecto empaqueta la aplicación web en una aplicación Android mediante WebView.

Fuente incluida:
app/src/main/assets/index.html

Versión de la aplicación:
1.0 (V76 de la aplicación web)

Para generar un APK de prueba:
1. Abrir esta carpeta con Android Studio.
2. Esperar a que Gradle sincronice el proyecto.
3. Ejecutar Build > Build APK(s), o usar:
   ./gradlew assembleDebug
4. El APK aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

Para Google Play se debe generar posteriormente un Android App Bundle (AAB) firmado.
