package com.metodoemocional.numerico;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(0xFFFFFFFF);
        window.setNavigationBarColor(0xFFFFFFFF);
        window.getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        // Social links must be handled by Android, not by the WebView.
        settings.setSupportMultipleWindows(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(String url) {
        if (url == null || url.startsWith("file://")) {
            return false;
        }

        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();

            // Open the three social networks outside the WebView.
            // Android will use the native app when installed, otherwise a browser.
            if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                String host = uri.getHost();
                if (host != null && isSocialHost(host)) {
                    Intent external = new Intent(Intent.ACTION_VIEW, uri);
                    external.addCategory(Intent.CATEGORY_BROWSABLE);
                    if (external.resolveActivity(getPackageManager()) != null) {
                        startActivity(external);
                    }
                    return true;
                }

                // Other web links can also be opened externally.
                Intent external = new Intent(Intent.ACTION_VIEW, uri);
                external.addCategory(Intent.CATEGORY_BROWSABLE);
                if (external.resolveActivity(getPackageManager()) != null) {
                    startActivity(external);
                }
                return true;
            }

            if ("intent".equalsIgnoreCase(scheme)) {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                    return true;
                }

                String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                if (fallbackUrl != null && !fallbackUrl.isEmpty()) {
                    Uri fallback = Uri.parse(fallbackUrl);
                    Intent browser = new Intent(Intent.ACTION_VIEW, fallback);
                    browser.addCategory(Intent.CATEGORY_BROWSABLE);
                    if (browser.resolveActivity(getPackageManager()) != null) {
                        startActivity(browser);
                    }
                }
                return true;
            }

            if ("mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                Intent external = new Intent(Intent.ACTION_VIEW, uri);
                if (external.resolveActivity(getPackageManager()) != null) {
                    startActivity(external);
                }
                return true;
            }
        } catch (Exception ignored) {
            // Keep the WebView stable if Android cannot handle a URL.
        }

        return true;
    }

    private boolean isSocialHost(String host) {
        host = host.toLowerCase();
        return host.equals("instagram.com") || host.endsWith(".instagram.com")
                || host.equals("tiktok.com") || host.endsWith(".tiktok.com")
                || host.equals("youtube.com") || host.endsWith(".youtube.com")
                || host.equals("youtu.be") || host.endsWith(".youtu.be");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
