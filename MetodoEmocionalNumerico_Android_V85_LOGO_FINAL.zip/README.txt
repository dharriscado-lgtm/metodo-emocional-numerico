Método Emocional Numérico - Android V85

Esta versión corrige definitivamente la apertura de enlaces externos:
TikTok, Instagram y YouTube se envían a Android mediante ACTION_VIEW,
por lo que el sistema puede abrir la app correspondiente o el navegador.

La aplicación web incluida es la V83.
Versión Android: 1.2, versionCode 3.

Compilación:
gradle assembleDebug
